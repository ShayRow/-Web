<?
require_once "data.php";
function addCsv($name,$phone,$password,$email,$lang,$item_list){
    $file = fopen('files/file.csv','r+');
    $l=[$name,$phone,$password,$email,implode(';',$lang),$item_list];
    fputcsv($file,$l,';');   
    fclose($file);
}
function viewTableCsv(){
    $file_read = fopen('files/file.csv','r');
    while(($filecsv = fgetcsv($file_read, 1000, ";")) !== FALSE){
               
        foreach($filecsv as $f){
            
            echo "<td>$f</td>";
        }
    }
    fclose($file_read);
}

function addjson($name,$phone,$password,$email,$lang,$item_list){
    $filejson = file_get_contents('files/file.json');
    $listJson = json_decode($filejson,TRUE);
    unset($filejson);
    $listJson = [
        "name"=>$name,
        "phone"=>$phone,
        "password"=>$password,
        "email"=>$email,
        "languages"=>implode(';',$lang),
        "item_list"=>$item_list
    ];
        
    file_put_contents('files/file.json',json_encode($listJson, JSON_UNESCAPED_UNICODE));
    unset($listJson);
}

function addtxt($name,$phone,$password,$email,$lang,$item_list){
    $filetxt = fopen('files/file.txt','r+');
    $ly=[$name,$phone,$password,$email,implode(',',$lang),$item_list];
    foreach($ly as $l){
        fputs($filetxt,$l.';');
    }
    fclose($filetxt);
}

