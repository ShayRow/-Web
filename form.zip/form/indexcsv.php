<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>csv</title>
    <link rel="stylesheet" href="style/style.css">

</head>
<body>
<?
    require_once "functions.php";
?>
    <table>
    <tr>
    <th>Имя:</th>
    <th>Телефон:</th>
    <th>Пароль:</th>
    <th>Email:</th>
    <th>Язык(и):</th>
    <th>Навык:</th>
    </tr>
    <tr><?=viewTableCsv();?></tr>
    </table>
    <input  type="button" onclick="location.href='index.php'" name="back" id="back" value="X">
</body>
</html>