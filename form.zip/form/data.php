<?php
$languages = ["python","C#","JavaScript","Java"];
$list = ["senior","middle","junior"];
$listcsv = [];