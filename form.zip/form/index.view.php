<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <form method="post">
        <div>
            <label for="name">Имя:</label>
            <input type="text" name="name" id="name" value="<?=$name?>" placeholder="Иванов Иван" class="view">
            <p><?=$msg[0]?></p>
            <br>
            <label for="phone">Телефон:</label>
            <input type="text" name="phone" id="phone" value="<?=$phone?>" placeholder="9013628631" class="view">
            <p><?=$msg[4]?></p>
            <br>
            <label for="password">Пароль:</label>
            <input type="password" name="password" id="password" value="<?=$password?>" class="view">
            <p><?=$msg[2]?></p>
            <br>
            <label for="password">Почта:</label>
            <input type="email" name="email" id="email" value="<?=$email?>" class="view">
            <p><?=$msg[1]?></p>
        </div>
        <div>
            <p>Языки:</p>
            <? foreach($languages as $item):?>
                <input type="checkbox" name="lang[]" value="<?=$item?>" id="<?=$item?>" <?=in_array($item,$lang)?"checked":""?> class="view">
                <label for="<?=$item?>"><?=$item?></label>
            <? endforeach;?>
            <p><?=$msg[3]?></p>
        </div>
        <br>
        <select name="item_list" id="item_list">
            <? foreach($list as $item):?>
            <option value="<?=$item?>"<?=($item==$item_list)?"selected":""?>><?= $item ?></option>
            <? endforeach;?>
        </select>
        <div>
            <button name="submit" id="submit">Отправить</button>
            <input  type="button" onclick="location.href='indexcsv.php'" name="viewscv" id="viewcsv" value="Посмотреть csv" class="view">
            <input  type="button" onclick="location.href='indexjson.php'" name="viewjson" id="viewjson" value="Посмотреть json" class="view">
            <input  type="button" onclick="location.href='indextxt.php'" name="viewtxt" id="viewtxt" value="Посмотреть txt" class="view">
        </div>
    </form>
</body>
</html>