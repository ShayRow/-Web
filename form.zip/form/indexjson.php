<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Json</title>
    <link rel="stylesheet" href="style/style.css">

</head>
<body>
<?
    require_once "functions.php";
    $filejson = file_get_contents('files/file.json');
    $listJson = json_decode($filejson,TRUE);
?>
    <table>
    <tr>
    <th>Имя:</th>
    <th>Телефон:</th>
    <th>Пароль:</th>
    <th>Email:</th>
    <th>Язык(и):</th>
    <th>Навык:</th>
    </tr>
    <tr>
    <?
    foreach($listJson as $key => $value):?>
    <td><?=$value?></td>
    <?endforeach;?>
    </tr>
    </table>
    <input  type="button" onclick="location.href='index.php'" name="back" id="back" value="X">
</body>
</html>