<?
require_once "data.php";
require_once "functions.php";
$name = $_POST["name"]??"";
$phone = $_POST["phone"]??"";
$password = $_POST["password"]??"";
$email = $_POST["email"]??"";
$lang = $_POST["lang"]??[];
$item_list = $_POST["item_list"]??"";

$pattern="/^[А-Я][а-я]{1,15} [А-ЩЭ-Я][а-я]{1,30}$/u";
$msg=[];
if(isset($_POST['submit'])){
    
    if(!preg_match($pattern,$name)){ 
        $msg[0]= "Некорректное имя";
    }

    if(!filter_var(filter_var(trim($email),FILTER_SANITIZE_EMAIL),FILTER_VALIDATE_EMAIL)){
        $msg[1] = "Email введён некоректно";
    }
    if(strlen($password)<=3){
        $msg[2] = "Пароль должен быть больше 3-х символов";
    }
    if(count($lang) == 0){
        $msg[3] = "Выберите хотя бы одно значение";
    }
    if(!preg_match("/^[0-9]{10,10}+$/",$phone)){
        $msg[4] = "Некоректный номер телефона";
    }


    if(count($msg)==0){
        
        //csv
        addCsv($name,$phone,$password,$email,$lang,$item_list);

        //json
        addjson($name,$phone,$password,$email,$lang,$item_list);

        //txt
        addtxt($name,$phone,$password,$email,$lang,$item_list);
        
        
        /*
        $filetxt = fopen('files/file.txt','r+');
        $text = [$name,$phone,$password,$email,implode(';',$lang),$item_list];
        fputs($filetxt,$text,';');
        fclose($filetxt);
        */
        
        
    }
    
}



require_once "index.view.php";